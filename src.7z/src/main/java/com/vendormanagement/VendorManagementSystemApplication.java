package com.vendormanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VendorManagementSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(VendorManagementSystemApplication.class, args);
    }
} 