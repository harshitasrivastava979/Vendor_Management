package com.vendormanagement.vendor_management_system.dto;

public class ServiceTypeRequestDto {

        private String name;
        private String description;

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }

}
